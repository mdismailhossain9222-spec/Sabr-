import Home from "./pages/Home";
import WhatsAppButton from "./components/WhatsAppButton";

export default function App() {
  return (
    <>
      <Home />
      <WhatsAppButton />
    </>
  );
}
